from DataSyncHelper import BaseSyncManager
default_app_config = 'e89_syncing.apps.E89SyncingConfig'
