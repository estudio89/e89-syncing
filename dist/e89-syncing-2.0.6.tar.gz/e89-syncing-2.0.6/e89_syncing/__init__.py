from DataSyncHelper import BaseSyncManager
__VERSION__ = "1.0.14"
default_app_config = 'e89_syncing.apps.E89SyncingConfig'
