# -*- coding: utf-8 -*-
from django.http import HttpResponse
from django.contrib.auth import get_backends
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from django.apps import apps
from django.shortcuts import get_object_or_404
import importlib

import e89_security.tools
import e89_syncing.syncing_utils
import DataSyncHelper
import json
import sys

@csrf_exempt
@e89_security.tools.secure_view(encryption_key=getattr(settings, "SYNC_ENCRYPTION_PASSWORD", ""), encryption_active=getattr(settings, "SYNC_ENCRYPTION", False))
def get_data_from_server(request, data, identifier = None):

    if not request.user.is_authenticated():
        user = None
    else:
        user = e89_syncing.syncing_utils.get_user_object(request.user)
        data["token"] = ""

    if getattr(settings, 'SYNC_DEBUG', False):
        print >>sys.stderr, 'GET DATA FROM SERVER: RECEIVED ' + json.dumps(data, ensure_ascii=False)

    token, timestamp, timestamps = e89_syncing.syncing_utils.extract_meta_data(data)
    platform = e89_syncing.syncing_utils.get_platform(request)

    if user is None:
        UserModel = apps.get_model(settings.SYNC_USER_MODEL)
        try:
            user = UserModel.objects.get(**{settings.SYNC_TOKEN_ATTR:token,settings.SYNC_TOKEN_ATTR + "__isnull":False})
        except UserModel.DoesNotExist:
            response = DataSyncHelper.getEmptyModifiedDataResponse()
            user = None

    if user is not None:
        if identifier is not None:
            response = DataSyncHelper.getModifiedDataForIdentifier(user = user, parameters = data, identifier = identifier, timestamps = timestamps, platform = platform)
        else:
            assert timestamp is not None or timestamps != {}, "Timestamp was not sent along with data."
            response = DataSyncHelper.getModifiedData(user = user, timestamp = timestamp, timestamps = timestamps, platform = platform)

    if getattr(settings, 'SYNC_DEBUG', False):
        print >>sys.stderr, 'GET DATA FROM SERVER: RESPONDED ' + json.dumps(response, ensure_ascii=False)

    return response

@csrf_exempt
@e89_security.tools.secure_view(encryption_key=getattr(settings, "SYNC_ENCRYPTION_PASSWORD", ""), encryption_active=getattr(settings, "SYNC_ENCRYPTION", False))
def send_data_to_server(request, data):

    if getattr(settings, 'SYNC_DEBUG', False):
        print >>sys.stderr, 'SEND DATA TO SERVER: RECEIVED ' + json.dumps(data, ensure_ascii=False)

    token, timestamp, timestamps = e89_syncing.syncing_utils.extract_meta_data(data)
    platform = e89_syncing.syncing_utils.get_platform(request)

    UserModel = apps.get_model(settings.SYNC_USER_MODEL)
    user = get_object_or_404(UserModel,**{settings.SYNC_TOKEN_ATTR:token})

    assert timestamp is not None or timestamps != {}, "Timestamp was not sent along with data."
    if data.has_key('registration_id'):
        device_id = data['registration_id']
    else:
        device_id = data['device_id']

    response = DataSyncHelper.saveNewData(user = user, timestamp = timestamp, timestamps = timestamps, device_id = device_id, data = data, files = request.FILES, platform = platform)

    if getattr(settings, 'SYNC_DEBUG', False):
        print >>sys.stderr, 'SEND DATA TO SERVER: RESPONDED ' + json.dumps(response, ensure_ascii=False)
    return response

@csrf_exempt
@e89_security.tools.secure_view(encryption_key=getattr(settings, "SYNC_ENCRYPTION_PASSWORD", ""), encryption_active=getattr(settings, "SYNC_ENCRYPTION", False))
def authenticate(request, data):
    ''' View para autenticação. Deve receber como parâmetro (via POST), um json no formato:

        {
            "username": "...",
            "senha": "..."
        }

    '''

    response = {}
    if request.method == "POST":

        username = data["username"]
        password = data["password"]

        module_name,class_name = getattr(settings,'SYNC_AUTHENTICATION','e89_syncing.authentication.BaseSyncAuthentication').rsplit('.',1)
        mod = importlib.import_module(module_name)
        SyncAuthentication = getattr(mod, class_name)

        platform = e89_syncing.syncing_utils.get_platform(request)
        response = SyncAuthentication().authenticate(username,password, platform=platform)

    return response

